package parcel;

public class ParcelLockerSystem {

    public static void main(String[] args) {
        ParcelLockerPresenter parcelLockerPresenter = new ParcelLockerPresenter();

        parcelLockerPresenter.showMenu();
    }
}
